public interface GuessingTree {
    public void add(String question, String directions);
}
